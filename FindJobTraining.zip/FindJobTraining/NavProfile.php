<?php
	session_start();
?>
<head>
<link rel="stylesheet" href="CSS/ProfileStyle.css">
</head>

<div class="sidenav">
	<?php
		if(isset($_SESSION['login_user']))
		{
	?>
	<a href="UserProfile.php">
		<?php
		echo $_SESSION['login_user'];
		}
		?>
	</a>
	<a href="HomeUser.php">Home</a>
	<a href="UserProfile.php">Profile</a>
	<a href="Resume.php">Resume</a>
	<a href="Contact.php">Contact</a>
	<a href="Logout">Log Out</a>
</div>