<?php 

if (session_status() == PHP_SESSION_NONE  || session_id() == '') {
        session_start();
    }

    require_once("connection.php");
    include("lib_function.php");
?>

<---header--->

<?php 
     include "connection.php";
     $sql = "SELECT name, email, nname, bln, gender e FROM user WHERE email = '" . $_SESSION['email'] . "'";
     $result = mysql_query($sql);
     if ($result !== false) {
         $row = mysql_fetch_array($result);
         echo "Hello, " . $row['name'] . " <br> " . $row['nname'] ."<br> " . $row['bln'] . " <br> " . $row['gender'] . "(" . $row['email'] . ").";
     } else {
       // an error has occured
       echo mysql_error();
       die;
             }
?>