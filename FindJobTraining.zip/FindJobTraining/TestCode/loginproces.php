<?php 

    session_start();

        require_once("connection.php");

        $email = $_POST['email'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $nname = $_POST['nname'];
        $bln = $_POST['bln'];
        $gender = $_POST['gender'];


        $cekuser = mysql_query("SELECT * FROM user WHERE email = '$email'");
        $jumlah = mysql_num_rows($cekuser);
        $hasil = mysql_fetch_array($cekuser);


        if($jumlah == 0) {
            echo "<script>alert('Email belum terdaftar!'); window.location = 'index.php'</script>";
        } else {
            if($password > $hasil['password']) {
            echo "<script>alert('Password Salah!'); window.location = 'index.php'</script>";
            } else {

            $_SESSION['email'] = $email;
            $_SESSION['password'] = $password;
            $_SESSION['name'] = $name;  
            $_SESSION['nname'] = $nname;    
            $_SESSION['bln'] = $bln;    
            $_SESSION['gender'] = $gender;  

            header('location:index.php');
            }
        }
    ?>