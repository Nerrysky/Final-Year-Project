-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 21, 2021 at 04:36 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `findjobtraining`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Email` varchar(225) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Employer` varchar(100) NOT NULL,
  `Course` char(100) NOT NULL,
  `Salary` float(10,2) NOT NULL,
  `JobDescription` varchar(225) NOT NULL,
  `Address` varchar(225) NOT NULL,
  `Country` char(100) NOT NULL,
  `Contact` varchar(16) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`ID`, `Email`, `Password`, `Employer`, `Course`, `Salary`, `JobDescription`, `Address`, `Country`, `Contact`) VALUES
(1, 'student@gmail.com', '1234', 'Faris', 'Teknologi Kimpalan', 600.00, 'pengalaman 2 tahun', '123asfasdf asd', 'Selangor', '01996121');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Nama` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `NoPhone` varchar(16) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Message` varchar(225) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
CREATE TABLE IF NOT EXISTS `signup` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Nama` char(100) NOT NULL,
  `IC` varchar(20) NOT NULL,
  `NoPhone` int(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `Jantina` char(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(8) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`ID`, `Nama`, `IC`, `NoPhone`, `Username`, `Date`, `Jantina`, `Email`, `Password`) VALUES
(1, 'Muhammad Faris Daneal Bin Azhan', '020814-11-0179', 108050179, 'Admin', '14/08/2002', 'Male', 'admin@gmail.com', '1408'),
(14, 'Muhammad Fareez Arfan Bin Azhan', '030908-11-0165', 199611234, 'Pentagon', '09/08/2003', 'Male', 'arfanfareez@gmail.com', '1234'),
(15, 'Miasarah Binti Zulkarnain', '021107-11-1256', 118792300, 'Mia123', '09/11/2002', 'Female', 'mia@gmail.com', '1200'),
(17, 'Muhammad Faris Daneal Bin Azhan', '020814-11-0179', 108050179, 'Nerrysky', '14/08/02', 'Male', 'MUHAMMAD116079@yes.my', '140802');

-- --------------------------------------------------------

--
-- Table structure for table `studentprofile`
--

DROP TABLE IF EXISTS `studentprofile`;
CREATE TABLE IF NOT EXISTS `studentprofile` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `Picture` varchar(225) NOT NULL,
  `IC` varchar(15) NOT NULL,
  `Course` char(100) NOT NULL,
  `Address` varchar(225) NOT NULL,
  `Resume` varchar(225) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentprofile`
--

INSERT INTO `studentprofile` (`ID`, `Picture`, `IC`, `Course`, `Address`, `Resume`) VALUES
(1, 'IMG_20200216_092832.jpg', '020814-11-0179', 'KPD', '1356-A, Kampung Kolam, Kuala Ibai, Kuala Terengganu', 'Laporan PTA.pdf');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
