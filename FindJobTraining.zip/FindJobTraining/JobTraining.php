<?php
include('Connection/config.php');
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="CSS/tablestyle.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<?php 
	include('headerUser.php');
?>
<div class="main">

<h1>Search Intent Job</h1>
<hr>

<h2>Company List</h2>
<div class="container">

	<p>Search Name Employer, Program, and Anything about company....</p>  
	<input class="form-control" id="myInput" type="text" placeholder="Search..">
	<br>

<div class="table-responsive">  
<table border = "1" class="table table-bordered table-striped">
     <tr>
		<th>Program Name</th>
		<th>Employer Name</th>
	    <th>Job Description</th>
		<th>COuntry</th>
		<th>Action</th>
	 </tr>

<tbody id="myTable">
<?php
	require('Connection/config.php');
     $senaraicompany=mysqli_query($connect,"SELECT * FROM company ORDER BY Program ASC");
     $no=1;
        while ($senarai=mysqli_fetch_array($senaraicompany))
        { 
?>
<tr>
	<td><?php echo $senarai['Program']; ?></td>
	<td><?php echo $senarai['Employer'] ?></td>
	<td><?php echo $senarai['JobDescription']; ?></td>
	<td><?php echo $senarai['Country']; ?></td>
	<td>
	<div class="btn-group btn-group-sm">
		<a href="CompanyDetails.php?id=<?php echo $senarai['ID']; ?>">
		<button type="button" class="btn btn-primary">Details</button>
		</a>
	</td>
</tr>
<?php
}
?>
</div>
</div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
</div>
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

</body>
</html>
