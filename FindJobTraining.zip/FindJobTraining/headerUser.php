<?php
	session_start();
?>
<header>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="CSS/AdminHeaderStyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  
</head>
<body>
<?php
		if(isset($_SESSION['login_user']))
		{
	?>
	<a href="UserProfile.php">
		<?php
		echo $_SESSION['login_user'];
		}
		?>
  <div class="wrapper">
    <nav>
      <input type="checkbox" id="show-search">
      <input type="checkbox" id="show-menu">
      <label for="show-menu" class="menu-icon"><i class="fas fa-bars"></i></label>
      <div class="content">
      <div class="logo"><a href="HomeUser.php">FindJobTraining</a></div>
        <ul class="links">
          <li><a href="HomeUser.php">Home</a></li>
          <li>
            <a href="JobTraining.php" class="desktop-link">Job Training Search</a>
            <input type="checkbox" id="show-features">
            <label for="show-features">Job Training Search</label>
            <ul>
              <li><a href="#">Advance Search</a></li>
              <li><a href="#">Job By Company</a></li>
              <li><a href="#">Job By Course</a></li>
              <li><a href="#"></a></li>
            </ul>
          </li>
		  <li>
		  <a href="UserProfile.php" class="desktop-link">Profile</a>
            <input type="checkbox" id="show-features">
            <label for="show-features">Profile</label>
            <ul>
              <li><a href="Resume.php">Resume</a></li>
              <li><a href="Contact.php">Contact</a></li>
            </ul>
          </li>
		  <li><a href="AboutUs.php">About Us</a></li>
		  <li><a href="signup.php">Register</a></li>
          <li><a href="logout.php">Log Out</a></li>
        </ul>
      </div>
      <label for="show-search" class="search-icon"><i class="fas fa-search"></i></label>
      <form action="#" class="search-box">
      </form>
    </nav>
  </div>
</body>
</html>
</header>