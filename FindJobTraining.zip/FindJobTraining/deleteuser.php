<?php
require"Connection/config.php";
$id=$_GET['delete_id'];
$result=mysqli_query($connect,"DELETE FROM signup WHERE ID=$id");
 echo "<script> alert('User has been removed');window.location='UserList.php'</script>";
?>