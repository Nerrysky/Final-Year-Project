<?php
session_start();
include('Connection/config.php');

 //getting ag from url
$id = $_GET['update_id'];
 
//selecting data associated with this particular ag
$senaraiuser = mysqli_query($connect, "SELECT * FROM signup WHERE ID='$id'");
?>

<html>
<head>
<meta charset="UTF-8">
<title>Admin | Update User</title>
<link rel="stylesheet" type="text/css" href="CSS/tablestyle.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<?php include('Tools/headerAdmin.php'); ?>
<br><br>

<div class="jumbotron text-center">
	<h2>User Update</h2>
	
<div class="container">
<div class="table-responsive">
<table border = "1" class="table table-bordered table-striped">
<form method="post" action="Connection/conupdate.php">
     <tr>
	 <th>Name</th>	
     <th>IC/No Kad Pengenalan</th>
	 <th>No Phone</th>
	 <th>Username</th>
	 <th>Date</th>	 
	 <th>Jantina</th>
	 <th>Email</th>	
	 <th>Password</th>
	 </tr>
	 
     <tr>
	 <td><input type="text" placeholder="insert new Name" name="Nama"></td>
	 <td><input type="text" placeholder="insert new IC" name="IC"></td>
	 <td><input type="text" placeholder="insert new No Phone" name="NoPhone"></td>
	 <td><input type="text" placeholder="insert new username" name="Username"></td>
	 <td><input type="text" placeholder="insert new Date" name="Date"></td>
	 <td><input type="text" placeholder="insert new Jantina" name="Jantina"></td>
	 <td><input type="text" placeholder="insert new Email" name="Email"></td>
	 <td><input type="text" placeholder="insert new Password" name="Password">
	    <input type="hidden" name="ID" value="<?php echo $id; ?>">
	 </td> 
	 </tr>
</table>
<button type="submit" name="Submit" value="Update" href="conupdate.php">UPDATE</button>
</div>
</div>
</div>

</form>
