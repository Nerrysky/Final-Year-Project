
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="CSS/AdminHeaderStyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
  <div class="wrapper">
    <nav>
      <input type="checkbox" id="show-search">
      <input type="checkbox" id="show-menu">
      <label for="show-menu" class="menu-icon"><i class="fas fa-bars"></i></label>
      <div class="content">
      <div class="logo"><a href="/FindJobTraining/Admin.php">Home Admin</a></div>
        <ul class="links">
          <li><a href="/FindJobTraining/Admin.php">Home</a></li>
          <li><a href="/FindJobTraining/UserList.php">User List</a></li>
          <li><a href="/FindJobTraining/CompanyList.php">Company List</a></li>
          <li>
            <a href="#" class="desktop-link">List Contact</a>
            <input type="checkbox" id="show-services">
            <label for="show-services">Services</label>
          </li>
          <li><a href="/FindJobTraining/logout.php">Log Out</a></li>
        </ul>
      </div>
      <label for="show-search" class="search-icon"><i class="fas fa-search"></i></label>
      <form action="#" class="search-box">
        <input type="text" placeholder="Type Something to Search..." required>
        <button type="submit" class="go-icon"><i class="fas fa-long-arrow-alt-right"></i></button>
      </form>
    </nav>
  </div>
</body>
