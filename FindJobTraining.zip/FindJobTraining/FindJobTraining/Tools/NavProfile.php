<head>
<link rel="stylesheet" href="CSS/ProfileStyle.css">
</head>
<div class="sidenav">
	<a href="/FindJobTraining/HomeUser.php">Home</a>
	<a href="/FindJobTraining/UserProfile.php">Profile</a>
	<a href="/FindJobTraining/InsertProfile.php">Insert Profile</a>
	<a href="/FindJobTraining/Resume.php">Resume</a>
	<a href="/FindJobTraining/Contact.php">Contact</a>
	<a href="/FindJobTraining/Logout">Log Out</a>
</div>