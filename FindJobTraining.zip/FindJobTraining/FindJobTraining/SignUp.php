<?php
include('Connection/config.php');
if(isset($_POST['Signup'])){
	$nama = $_POST['Nama'];
	$ic = $_POST['IC'];
	$no = $_POST['NoPhone'];
	$user = $_POST['Username'];
	$date = $_POST['Date'];
	$jantina = $_POST['Jantina'];
	$email = $_POST['Email'];
	$pass = $_POST['Password'];
	$result = mysqli_query($connect, "INSERT INTO signup ( Nama, IC, NoPhone, Username, Date, Jantina, Email, Password) 
							VALUES ( '$nama', '$ic', '$no', '$user', '$date', '$jantina', '$email','$pass')");
}
?>
   <head>
      <meta charset="utf-8">
      <title>Sign Up Form</title>
      <link rel="stylesheet" href="CSS/signupcss.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
   </head>
   <body>
      <div class="container">
         <header>Signup Form</header>
         <div class="progress-bar">
            <div class="step">
               <p>
                  Name
               </p>
               <div class="bullet">
                  <span>1</span>
               </div>
               <div class="check fas fa-check"></div>
            </div>
            <div class="step">
               <p>
                  Contact
               </p>
               <div class="bullet">
                  <span>2</span>
               </div>
               <div class="check fas fa-check"></div>
            </div>
            <div class="step">
               <p>
                  Birth
               </p>
               <div class="bullet">
                  <span>3</span>
               </div>
               <div class="check fas fa-check"></div>
            </div>
            <div class="step">
               <p>
                  Submit
               </p>
               <div class="bullet">
                  <span>4</span>
               </div>
               <div class="check fas fa-check"></div>
            </div>
         </div>
         <div class="form-outer">
            <form action="Connection/consignup.php">
               <div class="page slide-page">
                  <div class="title">
                     Basic Info:
                  </div>
                  <div class="field">
                     <div class="label">
                        Full Name
                     </div>
                     <input type="text" placeholder="Ali Bin Abu" name="Nama" required>
                  </div>
                  <div class="field">
                     <div class="label">
                        IC Number
                     </div>
                     <input type="text" placeholder="012345-67-8910" name="IC" required>
                  </div>
                  <div class="field">
                     <button class="firstNext next">Next</button>
                  </div>
				  <div>
					 <p>If you have register click link below!!</p>
					 <a href="login.php">Log In Page</a>
				  </div>
               </div>
               <div class="page">
                  <div class="title">
                     Student Info :
                  </div>
                  <div class="field">
                     <div class="label">
                        Email
                     </div>
                     <input type="text" placeholder="ali@gmail.com" name="Email" required>
                  </div>
                  <div class="field">
                     <div class="label">
                        Phone No
                     </div>
                     <input type="text" placeholder="0101234567" name="NoPhone" required>
                  </div>
                  <div class="field btns">
                     <button class="prev-1 prev">Previous</button>
                     <button class="next-1 next">Next</button>
                  </div>
               </div>
               <div class="page">
                  <div class="title">
                     Date of Birth:
                  </div>
                  <div class="field">
                     <div class="label">
                        Date
                     </div>
                     <input type="text" placeholder="12/12/2021" name="Date" required>
                  </div>
                  <div class="field">
                     <div class="label">
                        Gender
                     </div>
                     <select name="Jantina">
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                     </select>
                  </div>
                  <div class="field btns">
                     <button class="prev-2 prev">Previous</button>
                     <button class="next-2 next">Next</button>
                  </div>
               </div>
               <div class="page">
                  <div class="title">
                     Login Details:
                  </div>
                  <div class="field">
                     <div class="label">
                        Username
                     </div>
                     <input type="text" placeholder="Ali10" name="Username" required>
                  </div>
                  <div class="field">
                     <div class="label">
                        Password
                     </div>
                     <input type="password" placeholder="12345678" name="Password" required>
                  </div>
                  <div class="field btns">
                     <button class="prev-3 prev">Previous</button>
                     <button class="submit" value="Signup">Submit</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
      <script src="Script/script.js"></script>
   </body>