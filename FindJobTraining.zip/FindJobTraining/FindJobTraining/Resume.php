<!DOCTYPE html>
<?php
include('Connection/config.php');
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile | Resume Upload</title>
  <link rel="stylesheet" href="CSS/ResumeStyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
<?php include('Tools/NavProfile.php') ?>
<div class="main">
  <div class="wrapper">
    <header>Upload </header>
    <form action="conresume.php">
      <input class="file-input" type="file" name="file" hidden>
      <i class="fas fa-cloud-upload-alt"></i>
      <p>Browse File to Upload</p>
    </form>
    <section class="progress-area"></section>
    <section class="uploaded-area"></section>
  </div>
</div>

  <script src="Script/ResumeScript.js"></script>

</body>
</html>