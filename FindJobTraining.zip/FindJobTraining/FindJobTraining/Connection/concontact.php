<?php
include('config.php');
  $name = $_REQUEST['Nama'];
  $email = $_REQUEST['Email'];
  $phone = $_REQUEST['NoPhone'];
  $course = $_REQUEST['Course'];
  $message = $_REQUEST['Message'];
  $sql = "INSERT INTO contact (Nama, Email, NoPhone, Course, Message) VALUES ('$name', '$email', '$phone', '$course', '$message')";

  if($connect->query($sql) === TRUE) {
	echo "<script> alert('Message succefully');window.location='../Contact.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>