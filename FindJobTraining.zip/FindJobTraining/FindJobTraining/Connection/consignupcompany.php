<?php
include('config.php');
    $email = $_REQUEST['Email'];
	$pass = $_REQUEST['Password'];
	$emp = $_REQUEST['Employer'];
	$cour = $_REQUEST['Course'];
	$salary = $_REQUEST['Salary'];
	$job = $_REQUEST['JobDescription'];
	$address = $_REQUEST['Address'];
	$count = $_REQUEST['Country'];
	$cont = $_REQUEST['Contact'];
	$sql ="INSERT INTO company (Email, Password, Employer, Course, Salary, JobDescription, Address, Country, Contact) 
							VALUES ( '$email', '$pass', '$emp', '$cour', '$salary', '$job', '$address', '$count', '$cont')";

if($connect->query($sql) === TRUE) {
	echo "<script> alert('Register succefully');window.location='../LogInCompany.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>