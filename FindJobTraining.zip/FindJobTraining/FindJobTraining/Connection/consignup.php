<?php
include('config.php');
    $nama = $_REQUEST['Nama'];
	$ic = $_REQUEST['IC'];
	$no = $_REQUEST['NoPhone'];
	$user = $_REQUEST['Username'];
	$date = $_REQUEST['Date'];
	$jantina = $_REQUEST['Jantina'];
	$email = $_REQUEST['Email'];
	$pass = $_REQUEST['Password'];
	$sql = "INSERT INTO signup ( Nama, IC, NoPhone, Username, Date, Jantina, Email, Password) 
		    VALUES ('$nama', '$ic', '$no', '$user', '$date', '$jantina', '$email','$pass')";

if($connect->query($sql) === TRUE) {
	echo "<script> alert('Signup succefully');window.location='../login.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>