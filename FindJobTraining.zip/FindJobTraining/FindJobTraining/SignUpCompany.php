<?php
include('Connection/config.php');
if(isset($_POST['Signup'])){
	$email = $_POST['Email'];
	$pass = $_POST['Password'];
	$emp = $_POST['Employer'];
	$cour = $_POST['Course'];
	$salary = $_POST['Salary'];
	$job = $_POST['JobDescription'];
	$address = $_POST['Address'];
	$count = $_POST['Country'];
	$cont = $_POST['Contact'];
	$result = mysqli_query($connect, "INSERT INTO company (Email, Password, Employer, Course, Salary, JobDescription, Address, Country, Contact) 
							VALUES ( '$email', '$pass', '$emp', '$cour', '$salary', '$job', '$address', '$count', '$cont')");
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="CSS/SignUpCompany.css">
</head>
<body>

<form action="Connection/consignupcompany.php" style="border:1px solid #ccc">
  <div class="container">
    <h1>Register Your Company</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>

    <label for="Email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="Email" required>

    <label for="Password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="Password" required>

    <label for="Employer"><b>Employer</b></label>
    <input type="text" placeholder="Enter Employer Name" name="Employer" required>
	
	<label for="Course"><b>Course</b></label>
	<br>
    <select name="Course" required>
		<option>Course</option>
        <option>Teknologi Kimpalan</option>
        <option>Sistem Pengurusan Pangkalan Data & Aplikasi Web</option>
        <option></option>
    </select>
	<br><br>
	<label for="Salary"><b>Salary</b></label>
    <input type="text" placeholder="1000.00" name="Salary" required>
    
	<label for="JobDescription"><b>Job Description</b></label>
    <input type="text" placeholder="Enter The Description" name="JobDescription" required>
    
	<label for="Address"><b>Address</b></label>
    <input type="text" placeholder="123-A, Bandar Aman Jaya, Sungai Petani, Kedah" name="Address" required>
	
	<label for="Country"><b>Country</b></label>
	<br>
    <select name="Country" required>
		<option>Country</option>
        <option>Terengganu</option>
        <option>Kedah</option>
        <option>Kelantan</option>
		<option>Perak</option>
		<option>Perlis</option>
		<option>Pulau Pinang</option>
		<option>Kuala Lumpur</option>
		<option>Negeri Sembilan</option>
		<option>Johor</option>
		<option>Sabah</option>
		<option>Sarawak</option>
		<option>Selangor</option>
		<option>Putrajaya</option>
		<option>Pahang</option>
		<option>Melaka</option>
    </select>

	<br><br>
	<label for="Contact"><b>Contact</b></label>
    <input type="text" placeholder="0123456789" name="Contact" required>
	
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
	  <button type="submit" class="signup" value="Signup">Register Now</button>
	  <center>
	  <p>If You Have Register, Click Here For Log In.</p>
      <a href="LogInCompany.php" style="color:dodgerblue">Log In Here</a>
    </div>
  </div>
</form>
<script src="OptionScript.js"></script>
</body>
</html>