<!DOCTYPE html>
<?php include('Connection/config.php'); ?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profile | Insert Profile</title>
  <link rel="stylesheet" href="CSS/#">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
<?php include('Tools/NavProfile.php') ?>
<div class="main">
	
</div>

  <script src="Script/"></script>

</body>
</html>