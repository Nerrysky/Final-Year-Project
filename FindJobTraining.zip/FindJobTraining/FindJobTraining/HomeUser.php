<!doctype html>
<html>
<head>
<title>Home User</title>
<link rel="stylesheet" href="CSS/HomeUserStyle.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<style>
<style>
/*Image Show*/
* {
  box-sizing: border-box;
}

.img-container {
  float: left;
  width: 33.33%;
  padding: 2px;
  margin-top: 70px;
}

.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Testimonial*/
::selection{
  background: rgba(23,162,184,0.3);
}
.wrapper1{
  max-width: 1200px;
  margin: auto;
  padding: 0 20px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
}
.wrapper1 .box{
  background: #fff;
  width: calc(33% - 10px);
  padding: 25px;
  border-radius: 3px;
  box-shadow: 0px 4px 8px rgba(0,0,0,0.15);
}
.wrapper1 .box i.quote{
  font-size: 20px;
  color: #171c24;
}
.wrapper1 .box .content{
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  padding-top: 10px;
}
.box .info .name{
  font-weight: 600;
  font-size: 17px;
}
.box .info .job{
  font-size: 16px;
  font-weight: 500;
  color: #171c24;
}
.box .info .stars{
  margin-top: 2px;
}
.box .info .stars i{
  color: #171c24;
}
.box .content .image{
  height: 75px;
  width: 75px;
  padding: 3px;
  background: #17a2b8;
  border-radius: 50%;
}
.content .image img{
  height: 100%;
  width: 100%;
  object-fit: cover;
  border-radius: 50%;
  border: 2px solid #fff;
}
.box:hover .content .image img{
  border-color: #fff;
}

@media (max-width: 1045px) {
  .wrapper1 .box{
    width: calc(50% - 10px);
    margin: 10px 0;
  }
}
@media (max-width: 702px) {
  .wrapper1 .box{
    width: 100%;
  }
}
</style>
</style>
</head>
<body>
<?php include('Tools/headerUser.php') ?>

<div class="clearfix">
  <div class="img-container">
  <img src="Picture/Slide/1.png" alt="Italy" style="width:100%">
  </div>
  <div class="img-container">
  <img src="Picture/Slide/2.png" alt="Forest" style="width:100%">
  </div>
  <div class="img-container">
  <img src="Picture/Slide/3.png" alt="Mountains" style="width:100%">
  </div>
</div>

<div class="wrapper1">
    <div class="box">
      <i class="fas fa-quote-left quote"></i>
      <p>Lorem aliasry ipsum dolor sits ametans, consectetur adipisicing elitits. Expedita reiciendis itaque placeat thuratu, quasi yiuos repellendus repudiandae deleniti ideas fuga molestiae, alias.</p>
      <div class="content">
        <div class="info">
          <div class="name">Faris Daneal</div>
          <div class="job">Designer | Developer</div>
          <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i>
          </div>
        </div>
        <div class="image">
          <img src="Picture/IMG_20200216_092832.jpg" alt="">
        </div>
      </div>
    </div>
  </div>
<footer>
  <?php include('Tools/footer.php') ?>
</footer>

</body>
</html>

