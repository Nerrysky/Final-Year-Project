<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin | User List</title>
<link rel="stylesheet" type="text/css" href="CSS/tablestyle.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
<?php include('Tools/headerAdmin.php'); ?>
<br><br>
<div class="jumbotron text-center">
	<h2>User Listed</h2>

<div class="container">

	<p>Search Name, IC, and Anything about user....</p>  
	<input class="form-control" id="myInput" type="text" placeholder="Search..">
	<br>

<div class="table-responsive">  
<table border = "1" class="table table-bordered table-striped">
     <tr>
		<th>#</th>
	    <th>Nama</th>
		<th>IC</th>
		<th>No. Telefon</th>
		<th>Username</th>
		<th>Tarikh Lahir</th>
		<th>Jantina</th>
		<th>Email</th>
		<th>Password</th>
		<th>Actions</th>
	 </tr>
	 
	 
	 <tbody id="myTable">
	 <?php
     require('Connection/config.php');
     $senaraiuser=mysqli_query($connect,"SELECT * FROM signup ORDER BY Username ASC");
     $no=1;
        while ($senarai=mysqli_fetch_array($senaraiuser))
        {                          
     ?>
     <tr>
		<td><?php echo $senarai['ID']; ?></td>
	    <td><?php echo $senarai['Nama']; ?></td>
	    <td><?php echo $senarai['IC']; ?></td>
	    <td><?php echo $senarai['NoPhone']; ?></td>
		<td><?php echo $senarai['Username']; ?></td>
		<td><?php echo $senarai['Date']; ?></td>
		<td><?php echo $senarai['Jantina']; ?></td>
		<td><?php echo $senarai['Email']; ?></td>
		<td><?php echo $senarai['Password']; ?></td>
		<td>
			<div class="btn-group btn-group-sm">
				<a href="updateuser.php?update_id=<?php echo $senarai['ID']; ?>">
					<button type="button" class="btn btn-primary">EDIT</button>
				</a>
				<a href="deleteuser.php?delete_id=<?php echo $senarai['ID']; ?>">
					<button type="button" class="btn btn-primary">DELETE</button>
				</a>
			</div>
		</td>
     </tr>
<?php
}
?>
</tbody>
</table>
</div>
</div>
</div>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<br>
<?php include('Tools/footer.php') ?>
</body>
</html>