<!doctype html>
<html>
<?php 
session_start();

include('Connection/config.php'); 
if (isset($_SESSION['ID']) && isset($_SESSION['Email'])){
?>
<?php
}
?>

<head>
<title>Profile</title>

<link rel="stylesheet" href="CSS/ProfileStyle.css">
</head>
<body>
<br><br><br>
<?php include('Tools/NavProfile.php') ?>

<div class="main">

	<h1>Profile</h1>
	<!-- Profile Picture -->
	<img id="myImg" src="Picture/IMG_20200216_092832.jpg" alt="Profile Picture" style="width:80%;max-width:200px">
	
	
	<p>Email : <?php echo $_SESSION['Email']; ?></p>
	<p>Pssword : <?php echo $_SESSION['Password']; ?></p>
	<p></p>
	<p></p>
	<p></p>
	<p></p>
	<p></p>
	
	<!-- The Modal -->
	<div id="myModal" class="modal">
	<span class="close">&times;</span>
	<img class="modal-content" id="img01">
	<div id="caption"></div>
</div>
</div>

<script src="Script/ProfileScript.js"></script>
</body>
</html>