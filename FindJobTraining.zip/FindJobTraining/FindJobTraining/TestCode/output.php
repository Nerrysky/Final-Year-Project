<div class="result">

<!-- Check if the session variable was set -->
<?php if(isset($_SESSION["name"])) { ?>
    <table>
        <tr>
            <td>Name</td>
            <td><?= $_SESSION['name'] ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?= $_SESSION['email'] ?></td>
        </tr>
        <tr>
            <td>Phone</td>
            <td><?= $_SESSION['phone'] ?></td>
        </tr>
    </table>

<?php } else { echo "You haven't login yet!!"; }?>

</div>