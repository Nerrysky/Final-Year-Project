<div class="main">
    <div id="container">
        <form method="post" action="login.php" id="login">
            <label for="username">Username</label>
            <input type="text" name="username" id="username">

            <label for="password">password</label>
            <input type="password" name="password" id="password">

            <input type="submit" name="submit" value="Login">
        </form>
    </div>
</div>

<hr>
<div class="result">
    <table>
        <tr>
            <td>Name</td>
            <td></td>
        </tr>
        <tr>
            <td>Email</td>
            <td></td>
        </tr>
        <tr>
            <td>Phone</td>
            <td></td>
        </tr>
    </table>

</div>