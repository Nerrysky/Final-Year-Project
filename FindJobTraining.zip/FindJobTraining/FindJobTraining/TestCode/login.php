<?php

// Starting the Session
session_start();

// Clear all the previously saved sessions
// remove all session variables
session_unset();

// destroy the session
session_destroy();

$conn = new mysqli('localhost', 'root','', 'logintest');
if (!$conn) {
    die('Could not connect:' . mysqli_error());
}

// Check if this form was submitted
if (isset($_POST['username'])) {

    // Get the Posted Informations and assigned them to the local variables
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Set the query String
    $sql = "SELECT * FROM log WHERE `name` = '$username' LIMIT 1";
    
    // Reading the Specific Record
    $query = $conn->query($sql);

    // Check if record exist
    if ($query->num_rows > 0) {

        // Loop through the retrieve records
        while($record = $query->fetch_assoc()) {

            // Validate password
            if ($password == $record["password"]) {

                // Save the User Profile for later use
                $_SESSION['id'] = $record["id"];
                $_SESSION['name'] = $record["name"];
                $_SESSION['email'] = $record["email"];  
                $_SESSION['phone'] = $record["phone"];
            } else {
                echo "Invalid password";
            }
        }
    } else {
          echo 'Record found for the selected!';
    }    
}

?>