<?php
include('Connection/config.php');
if(isset($_POST['Signup'])){
	$photo = $_POST['Photo'];
	$nama = $_POST['Nama'];
	$ic = $_POST['IC'];
	$no = $_POST['NoPhone'];
	$cour = $_POST['Course'];
	$user = $_POST['Username'];
	$date = $_POST['Date'];
	$jantina = $_POST['Jantina'];
	$add = $_POST['Address'];
	$email = $_POST['Email'];
	$pass = $_POST['Password'];
	$result = mysqli_query($connect, "INSERT INTO signup ( Photo, Nama, IC, NoPhone, Course, Username, Date, Jantina, Address, Email, Password) 
							VALUES ( '$photo', '$nama', '$ic', '$no', '$user', '$cour', '$date', '$jantina', '$add', '$email','$pass')");
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="CSS/SignUpCompany.css">
<title>Student | Register Form</title>
</head>
<body>

<form action="Connection/consignup.php" style="border:1px solid #ccc">
  <div class="container">
  <h2>Student Register Form</h2>
  <p>Please fill in this form to create an account.</p>
  <hr>
  
  <label for="Picture"><b>Profile Picture</b></label>
			<br>
			<input type="file" id="files" name="Photo" multiple>
			<br>
			<br>
			
			<!-- Info Pelajar -->
			<hr>
			<label for="Nama"><b>Full Name</b></label>
			<br>
			<input type="text" placeholder="Put Your Full Name" name="Nama" required>
			<br>
			<br>
			<label for="IC"><b>Identification Card</b></label>
			<br>
			<input type="text" placeholder="Put Your IC here..." name="IC" required>
			<br>
			<br>
			<label for="Address"><b>Address</b></label>
			<br>
			<input type="text" placeholder="Put Your Address here..." name="Address" style="height: 100px;" required>
			<br>
			<br>
			
			<!-- Email dan Password Pelajar -->
			<hr>
			<label for="Username"><b>Username</b></label>
			<br>
			<input type="text" placeholder="Put Your Username here..." name="Username" required>
			<br>
			<br>
			<label for="Email"><b>Email</b></label>
			<br>
			<input type="text" placeholder="Put Your Email here..." name="Email" required>
			<br>
			<br>
			<label for="IC"><b>Password</b></label>
			<br>
			<input type="text" placeholder="Put Your Password here..." name="Password" required>
			<br>
			<br>
			
			<!-- Maklumat Pelajar -->
			<hr>
			<label for="Course"><b>Course</b></label>
			<br>
			<select name="Course" required>
				<option>Course</option>
				<option>Sistem Pengurusan Pangkalan Data Dan Aplikasi Web</option>
				<option>Teknologi Pemisinan Industri</option>
				<option>Sistem Komputer</option>
				<option>Teknologi Kimpalan</option>
			</select>
			<br>
			<br>
			<label for="Gender"><b>Gender</b></label>
			<br>
			<input type="radio" name="Jantina" id="Male" required>
			<label for="Male">Male</label>
			<input type="radio" name="Jantina" id="Female" required>
			<label for="Female">Female</label>
			<br>
			<br>
			<label for="Date Of Birth"><b>Date Of Birth</b></label>
			<br>
			<input type="date" id="birthday" name="Date">
			<br>
			<br>

<p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
	  <button type="submit" class="signup" value="Signup">Register Now</button>
	  <center>
	  <p>If You Have Register, Click Here For Log In.</p>
      <a href="login.php" style="color:dodgerblue">Log In Here</a>
    </div>
  </div>
</form>
<script src="Script/OptionScript.js"></script>
</body>
</html>