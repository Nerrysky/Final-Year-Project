<?php
require('Connection/config.php');
?>
<?php
if ($_SESSION['ID']) {
?>
<!doctype html>
<html>
<head>

</head>
<body>
<?php include('headerUser.php'); ?>
</body>
</html>
<?php
}
?>