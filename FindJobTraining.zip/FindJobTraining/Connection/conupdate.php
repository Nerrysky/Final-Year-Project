<?php
include('config.php');
	$id = $_POST['ID'];
    $nama = $_POST['Nama'];
	$ic = $_POST['IC'];
	$no = $_POST['NoPhone'];
	$user = $_POST['Username'];
	$date = $_POST['Date'];
	$jantina = $_POST['Jantina'];
	$email = $_POST['Email'];
	$pass = $_POST['Password'];

$sql = "UPDATE signup SET Nama='$nama', IC='$ic', NoPhone='$no', Username='$user', Date='$date', Jantina='$jantina', Email='$email', Password='$pass' WHERE ID='$id'";


if ($connect->query($sql)=== TRUE) {
	echo "Record updated succesfully";
}else{
	echo "Error updating record: ". mysqli_error($connect);
}

mysqli_close($connect);
header("location:../UserList.php");

?>