<?php
include('config.php');
	$photo = $_REQUEST['Photo'];
    $nama = $_REQUEST['Nama'];
	$ic = $_REQUEST['IC'];
	$no = $_REQUEST['NoPhone'];
	$prog = $_REQUEST['Program'];
	$user = $_REQUEST['Username'];
	$date = $_REQUEST['Date'];
	$jantina = $_REQUEST['Jantina'];
	$add = $_REQUEST['Address'];
	$email = $_REQUEST['Email'];
	$pass = $_REQUEST['Password'];
	$sql = "INSERT INTO signup ( Photo, Nama, IC, NoPhone, Program, Username, Date, Jantina, Address, Email, Password) 
		    VALUES ( '$photo','$nama', '$ic', '$no', '$prog', '$user', '$date', '$jantina', '$add', '$email','$pass')";

if($connect->query($sql) === TRUE) {
	echo "<script> alert('Signup succefully');window.location='../login.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>