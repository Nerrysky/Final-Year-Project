<?php
include('config.php');
    $pic = $_REQUEST['Picture'];
	$ic = $_REQUEST['IC'];
	$cour = $_REQUEST['Course'];
	$add = $_REQUEST['Address'];
	$res = $_REQUEST['Resume'];
	$sql = "INSERT INTO studentprofile ( Picture, IC, Course, Address, Resume) VALUES ('$pic', '$ic', '$cour', '$add', '$res')";

if($connect->query($sql) === TRUE) {
	echo "<script> alert('Signup succefully');window.location='../UserProfile.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>