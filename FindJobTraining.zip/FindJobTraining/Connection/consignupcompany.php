<?php
include('config.php');
    $email = $_REQUEST['Email'];
	$pass = $_REQUEST['Password'];
	$emp = $_REQUEST['Employer'];
	$program = $_REQUEST['Program'];
	$salary = $_REQUEST['Salary'];
	$job = $_REQUEST['JobDescription'];
	$address = $_REQUEST['Address'];
	$count = $_REQUEST['Country'];
	$cont = $_REQUEST['Contact'];
	$sql ="INSERT INTO company (Email, Password, Employer, Program, Salary, JobDescription, Address, Country, Contact) 
							VALUES ( '$email', '$pass', '$emp', '$program', '$salary', '$job', '$address', '$count', '$cont')";

if($connect->query($sql) === TRUE) {
	echo "<script> alert('Register succefully');window.location='../LogInCompany.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>