<?php
session_start();
include('config.php');

if (isset($_POST['Email']) && isset($_POST['IC']) && isset($_POST['Password'])){
	
	function validate($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
	$email = validate($_POST['Email']);
	$ic = validate($_POST['IC']);
	$pass = validate($_POST['Password']);
	
	if (empty($email)) {
		header("Location: ../login.php?error=Email is required");
	    exit();
	}else if(empty($pass)) {
		header("Location: ../login.php?error=Password is required");
	    exit();
	}else{
		$sql = "SELECT * FROM signup WHERE Email='$email' AND Password='$pass'";
		
		$result = mysqli_query($connect, $sql);
		
		if (mysqli_num_rows($result) === 1){
			$row = mysqli_fetch_assoc($result);
			if ($row['Email'] === $email && $row['IC'] === $ic && $row['Password'] === $pass){
				$_SESSION['Email'] = $row['Email'];
				$_SESSION['IC'] = $row['IC'];
				$_SESSION['Password'] = $row['Password'];
				$_SESSION['ID'] = $_row['ID'];
			}    
		}if($row['Email']=="admin@gmail.com"){
          header("location:../Admin.php");
        }else if($row['Email']){
          header("location:../HomeUser.php");
		}else{
		  header("Location: ../login.php?error=Incorrect Email or Password");
	      exit();
		}
	}
}
?>