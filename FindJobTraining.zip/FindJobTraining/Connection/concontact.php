<?php
include('config.php')
  $name = $_REQUEST['Nama'];
  $email = $_REQUEST['Email'];
  $message = $_REQUEST['Message'];
  $sql = "INSERT INTO contact (Nama, Email, Message) VALUES ('$name', '$email', '$message')";

if($connect->query($sql) === TRUE) {
	echo "<script> alert('Signup succefully');window.location='.../HomeUser.php'</script>";
}else{
	echo "Error: ". $sql . "<br>" . $connect->error;
}

$connect ->close();
?>