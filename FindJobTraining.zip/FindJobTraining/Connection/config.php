<?php
//DATABASE CONNECTION
$server = "localhost";
$user = "root";
$pass = "";
$db = "findjobtraining";
$connect=mysqli_connect("localhost","root","","findjobtraining");
?>