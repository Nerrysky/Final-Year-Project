<?php 
session_start(); 
include "Connection/config.php";

if (isset($_POST['Username']) && isset($_POST['Password'])
    && isset($_POST['Nama']) && isset($_POST['re_password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$uname = validate($_POST['Username']);
	$pass = validate($_POST['Password']);

	$re_pass = validate($_POST['re_password']);
	$name = validate($_POST['Nama']);

	$user_data = 'Username='. $uname. '&Nama='. $name;


	if (empty($uname)) {
		header("Location: SignUp.php?error=User Name is required&$user_data");
	    exit();
	}else if(empty($pass)){
        header("Location: SignUp.php?error=Password is required&$user_data");
	    exit();
	}
	else if(empty($re_pass)){
        header("Location: SignUp.php?error=Re Password is required&$user_data");
	    exit();
	}

	else if(empty($name)){
        header("Location: signup.php?error=Name is required&$user_data");
	    exit();
	}

	else if($pass !== $re_pass){
        header("Location: SignUp.php?error=The confirmation password  does not match&$user_data");
	    exit();
	}

	else{

		// hashing the password
        $pass = md5($pass);

	    $sql = "SELECT * FROM signup WHERE Username='$uname' ";
		$result = mysqli_query($connect, $sql);

		if (mysqli_num_rows($result) > 0) {
			header("Location: SignUp.php?error=The username is taken try another&$user_data");
	        exit();
		}else {
           $sql2 = "INSERT INTO signup(Username, Password, Nama) VALUES('$uname', '$pass', '$name')";
           $result2 = mysqli_query($connect, $sql2);
           if ($result2) {
           	 header("Location: SignUp.php?success=Your account has been created successfully");
	         exit();
           }else {
	           	header("Location: SignUp.php?error=unknown error occurred&$user_data");
		        exit();
           }
		}
	}
	
}else{
	header("Location: SignUp.php");
	exit();
}