<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "job_portal";
?>