<!doctype html>
<html>
<head>
</head>
<body>
<?php include('Tools/headerAdmin.php') ?>

</body>
</html>